"""Minimal LLM adapter: Anthropic, any OpenAI-compatible endpoint (OpenAI, Groq, Gemini, Ollama, OpenRouter),
or none, in which case the app answers in extractive mode (verbatim report sentences + citations).
Model names change often: set LLM_MODEL in .env to whatever your provider currently offers.
"""
from __future__ import annotations

import os

import config

DEFAULT_MODELS = {
    "anthropic": "claude-haiku-5-5",
    "openai": "gpt-4o-mini",
    "groq": "llama-3.3-70b-versatile",
    "gemini": "gemini-2.5-flash",
    "ollama": "llama3.1:8b",
    "openrouter": "",
}
BASE_URLS = {
    "groq": "https://api.groq.com/openai/v1",
    "gemini": "https://generativelanguage.googleapis.com/v1beta/openai/",
    "ollama": "http://localhost:11434/v1",
    "openrouter": "https://openrouter.ai/api/v1",
}
KEY_ENV = {"anthropic": "ANTHROPIC_API_KEY", "openai": "OPENAI_API_KEY", "groq": "GROQ_API_KEY",
           "gemini": "GEMINI_API_KEY", "openrouter": "OPENROUTER_API_KEY"}


class LLM:
    def __init__(self, provider: str, model: str, client):
        self.provider, self.model, self.client = provider, model, client
        self._structured = True  # switched off if the provider rejects structured-output options
        self._openai_extra: dict | None = None  # remembers which parameter set the endpoint accepted

    def complete(self, system: str, user: str, max_tokens: int = 800, schema: dict | None = None) -> str:
        if self.provider == "anthropic":
            return self._anthropic(system, user, max_tokens, schema)
        return self._openai(system, user, max_tokens, schema)

    def _anthropic(self, system, user, max_tokens, schema) -> str:
        import anthropic

        kwargs = dict(model=self.model, max_tokens=max_tokens, system=system,
                      messages=[{"role": "user", "content": user}])
        if self._structured:
            output_config = {"effort": "low"}  # low effort = faster answers; the task is extraction, not reasoning
            if schema:
                output_config["format"] = {"type": "json_schema", "schema": schema}
            try:
                return _anthropic_text(self.client.messages.create(**kwargs, output_config=output_config))
            except (TypeError, anthropic.BadRequestError) as exc:
                print(f"[llm] {self.model} rejected output_config ({str(exc)[:120]}); using plain JSON prompting")
                self._structured = False
        return _anthropic_text(self.client.messages.create(**kwargs))

    def _openai(self, system, user, max_tokens, schema) -> str:
        import openai

        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        options = [self._openai_extra] if self._openai_extra else []
        if schema and self._structured:
            options.append({"response_format": {"type": "json_object"}, "temperature": 0, "max_tokens": max_tokens})
        options += [{"temperature": 0, "max_tokens": max_tokens},
                    {"max_completion_tokens": max(2000, max_tokens)}]  # reasoning models reject the two above
        last_error = None
        for extra in options:
            try:
                response = self.client.chat.completions.create(model=self.model, messages=messages, **extra)
                self._openai_extra = extra
                return response.choices[0].message.content or ""
            except openai.BadRequestError as exc:
                last_error = exc
                if "response_format" in extra:
                    self._structured = False
        raise last_error


def _anthropic_text(response) -> str:
    return "".join(getattr(block, "text", "") for block in response.content)


def get_llm() -> LLM | None:
    """Build the configured client, or return None (extractive mode) if nothing usable is configured."""
    provider = config.LLM_PROVIDER or next(
        (p for p in ("anthropic", "openai", "groq", "gemini", "openrouter") if os.getenv(KEY_ENV[p])), "none")
    if provider == "none":
        return None
    model = config.LLM_MODEL or DEFAULT_MODELS.get(provider, "")
    if not model:
        print(f"[llm] set LLM_MODEL in .env for provider {provider!r}; using extractive mode")
        return None
    key = (os.getenv(KEY_ENV.get(provider, "") or "_", "") or (os.getenv("GOOGLE_API_KEY", "") if provider == "gemini" else "")
           or os.getenv("LLM_API_KEY", ""))
    if not key and provider != "ollama" and not config.LLM_BASE_URL:
        print(f"[llm] no API key set for {provider!r} (see .env.example); using extractive mode")
        return None
    try:
        if provider == "anthropic":
            import anthropic

            client = anthropic.Anthropic(api_key=key, timeout=60, max_retries=1)
        else:
            import openai

            base_url = config.LLM_BASE_URL or BASE_URLS.get(provider)
            client = openai.OpenAI(api_key=key or "none", base_url=base_url, timeout=60, max_retries=1)
    except Exception as exc:
        print(f"[llm] {provider} unavailable ({exc}); using extractive mode")
        return None
    return LLM(provider, model, client)
